<?php

$conn = mysqli_connect('localhost','root','','North_hall');

?>