<footer class="footer">

   &copy; copyright @ <?= date('Y'); ?> by <span>Tarek Hosen | Tanvir Mahmud</span> | all rights reserved!

</footer>
<style>
    .footer{
      position: relative;
      background-color: blueviolet;
      border-top: var(--border);
      text-align: center;
      color: var(--black);
      font-size: 2rem;
      
   /* padding-bottom: 9.5rem; */
   }

   .footer span{
   color: var(--main-color);
}
</style>